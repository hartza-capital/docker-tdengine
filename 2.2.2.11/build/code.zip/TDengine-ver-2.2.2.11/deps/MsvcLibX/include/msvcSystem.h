﻿/* CoreUtils global system configuration definitions */

